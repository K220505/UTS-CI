<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <title>Dashboard</title>
    <style>
      body {
        background-color: #f8f9fa;
      }
      .navbar {
        background: linear-gradient(90deg, #0062E6, #33AEFF);
      }
      .navbar a {
        color: white !important;
      }
      .sidebar {
        background: linear-gradient(180deg, #343a40, #212529);
        height: 100vh;
        position: fixed;
        top: 56px; /* tetap di bawah navbar */
        left: 0;
        width: 230px;
        z-index: 100;
        padding-top: 10px;
      }
      .sidebar h4 {
        font-size: 18px;
        margin-bottom: 20px;
      }
      .sidebar .list-group-item {
        background: transparent;
        color: #ffffff;
        border: none;
        font-weight: 500;
        padding: 12px 20px;
      }
      .sidebar .list-group-item:hover {
        background-color: #495057;
        border-radius: 5px;
      }
      .main-content {
        margin-left: 230px;
        padding: 20px;
        padding-top: 80px; /* menyesuaikan jarak dengan navbar */
      }
      .card-header {
        background: linear-gradient(90deg, #0062E6, #33AEFF);
        color: white;
      }
      .card-body {
        background-color: #ffffff;
        border-top: 5px solid #007bff;
      }
      .card {
        margin-bottom: 20px;
        box-shadow: 0px 2px 10px rgba(0,0,0,0.1);
      }
    </style>
  </head>
  <body>

    <!-- Navbar -->
    <!-- Full Navbar (revisi) -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background: linear-gradient(90deg, #56ab2f, #a8e063);">
      <a class="navbar-brand" href="#">Dashboard</a>
    </nav>



    <!-- Sidebar -->
    <div class="sidebar d-flex flex-column p-3">
      <h4 class="text-white text-center">Main Menu</h4>
      <ul class="list-group list-group-flush">
        <a href="<?php echo base_url() ?>index.php/dashboard" class="list-group-item">Dashboard</a>
        <a href="#" class="list-group-item">Profile</a>
        <a href="<?php echo base_url() ?>index.php/dashboard/logout" class="list-group-item">Logout</a>
      </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <!-- Dashboard Card -->
            <div class="card">
              <div class="card-header">
                <h5>Welcome to your Dashboard</h5>
              </div>
              <div class="card-body">
                <p class="lead">Selamat Datang, <?php echo $this->session->userdata("nama_lengkap") ?>!</p>
                <p>Ini adalah dashboard Anda. Anda dapat melihat informasi lebih lanjut di sini.</p>
                <div class="alert alert-info">
                  <strong>Note:</strong> Pastikan untuk memeriksa profil Anda untuk memperbarui informasi penting.
                </div>
              </div>
            </div>

            <!-- Another Card Example -->
            <div class="card">
              <div class="card-header">
                <h5>Recent Activities</h5>
              </div>
              <div class="card-body">
                <ul>
                  <li>Login pada 17 April 2025</li>
                  <li>Update profil pada 15 April 2025</li>
                  <li>Memverifikasi email pada 10 April 2025</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  </body>
</html>
